import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-answers',
  imports: [],
  templateUrl: './manage-answers.component.html',
  styleUrl: './manage-answers.component.css'
})
export class ManageAnswersComponent {

}
