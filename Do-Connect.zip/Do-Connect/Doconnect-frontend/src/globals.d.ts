declare function describe(description: string, spec: () => void): void;
declare function it(description: string, spec: () => void): void;
declare function beforeEach(spec: () => void): void;
declare function expect(actual: any): any;
