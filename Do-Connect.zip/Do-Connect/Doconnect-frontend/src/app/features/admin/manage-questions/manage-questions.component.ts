import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-questions',
  imports: [],
  templateUrl: './manage-questions.component.html',
  styleUrl: './manage-questions.component.css'
})
export class ManageQuestionsComponent {

}
