export const environment = {
  production: true,
  apiUrl: 'https://api.example.com'
};
