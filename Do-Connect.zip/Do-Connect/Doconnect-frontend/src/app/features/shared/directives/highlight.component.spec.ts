import { HighlightDirective } from './highlight.directive.component';

describe('Highlight', () => {
  it('should create an instance', () => {
    const directive = new Highlight();
    expect(directive).toBeTruthy();
  });
});
